
var anotherwindow;

function showwindow(){

var hei = document.getElementById("height").value;
var wid = document.getElementById("width").value;
var Lef = document.getElementById("Left").value;
var To = document.getElementById("Top").value;

var he= parseInt(hei);
var wi= parseInt(wid);
var Le= parseInt(Lef);
var T= parseInt(To);

anotherwindow = window.open ("","","width="+wi+",height="+he+",top="+T+",")
}