var anotherwindow;
function Invoice() {
   var qty1 = parseInt(document.getElementById('qty1').value);
   var qty2 = parseInt(document.getElementById('qty2').value); 
   var qty3 = parseInt(document.getElementById('qty3').value);
   var qty4 = parseInt(document.getElementById('qty4').value);
   
   if (qty1 >0 || qty2>0 || qty3>0 || qty4>0) {
 
    anotherwindow= window.open("","","width= 400,height= 400");
    anotherwindow.document.write("<table align='center' border='1'><caption>Invoice </caption>");
    anotherwindow.document.write("<tr><th>Product</th><th>Quantity</th><th>Price</th><th>Total</th>");
   
   if (qty1>0){
anotherwindow.document.write("<tr><td>Barbie Doll</td><td>"+qty1+"</td><td>20</td><td>"+qty1*20+"</td></tr>");
   } 
   if (qty2>0){      
    anotherwindow.document.write("<tr><td>Calculator</td><td>"+qty2+"</td><td>30</td><td>"+qty2*30+"</td></tr>");
   }
   if (qty3>0){
    anotherwindow.document.write("<tr><td>Mobile</td><td>"+qty3+"</td><td>40</td><td>"+qty3*40+"</td></tr>");
   }
   if (qty4>0){
       anotherwindow.document.write("<tr><td>LG DVD</td><td>"+qty4+"</td><td>50</td><td>"+qty4*50+"</td></tr>");
   }
      
   } else{
        alert("no item selected");
   }

}