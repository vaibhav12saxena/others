function change(){
    
    var product = document.getElementById("pro").value;
    
    
    /*if (product=="Grocery"){
        document.getElementById("t1").innerHTML= <select name="product" id ="p2">
        <option value="Soap">Soap</option>
        <option value="Powder">Powder</option>
      </select
      */
    
    if (product=="Electronics"){
        document.getElementById("productlist").innerHTML="<option>Select</option><option value="+20000+">Television</option><option value="+30000+">Laptop</option><option value="+10000+">Phone</option>";
       }
       else if (product=="Grocery"){
        document.getElementById("productlist").innerHTML="<option>Select</option><option value="+40+">Soap</option><option value="+90+">Powder</option>";
       }
       
       else {
        document.getElementById("productlist").innerHTML="";   
    }
   
}



function showdata(){
    var quan = parseInt(document.getElementById("q").value);
    var totalprice= quan*(document.getElementById("productlist").value);
    document.getElementById("tp").value= totalprice;
}