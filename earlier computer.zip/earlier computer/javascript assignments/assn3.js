function compute(){
    var V1= parseInt(document.getElementById("v1").value);
    var V2= parseInt(document.getElementById("v2").value);
    var V3= parseInt(document.getElementById("v3").value);
    
    if (V1>15){
        alert("Loan amount should be less than 15 Lakhs");
    }
    else if (V3<7 || V3>15) {
        alert("Payment years should be between 7 and 15");
    }
    else{
        document.getElementById("q1").value=V1;
        document.getElementById("q2").value=V2;
        document.getElementById("q3").value=V3;
    }
    
}