


    function showdata()
    {
        var anotherwindow;
        console.log("welcomw to delhi");
        alert("Hi");
        anotherwindow = window.open("","","height=200","width200");
    anotherwindow.document.write("Javascript ES6 from Full Stack");
}