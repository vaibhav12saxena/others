 
/*assigment 1


 var markh = prompt("what is mark height in meters");
 var markm = prompt("what is mark weight in kg"); 
 var johnh = prompt("what is johm height in meters");
 var johnm = prompt("what is john weight in kg");
 var BMIm = markm/(markh)^2;
 var BMIj = johnm/(johnh)^2;
 var t = BMIm > BMIj;
 console.log(BMIm);
 console.log(BMIj);
 console.log("Is mark BMI is highr?" +t);
*/

//assignment2
/*
var jsa = (84+120+103)/3;
var msa = (116+94+123)/3;

if (jsa>msa) {
      console.log("John wins."+"He has scored an average of "+ jsa);
} else if (msa>jsa) {
     console.log("Mike wins."+"He has scored an average of "+msa);  
} else {
     console.log("No one wins."+"They have scored an average of "+jsa);  
}
*/
//objects
/*
var john = {
      name: 'Rahul',
      birthyear: 1996,
      age: function(){
            this.age = 2018- birthyear;
      },
      lastname: 'Gupta'
}
console.log(john);

*/


//assignemnt 4
/*

var Mark = {
      fullname: 'Mark broke',
      height: 1.70,
      weight: 72,
      birthyear:1990,
      calBMI: function(){
            this.BMI = this.weight/(this.height * this.height);
            return this.BMI;
      }
}


var john=  {
      fullname: 'John look',
      height: 1.65,
      weight: 57,
      birthyear:1990,
         calBMI: function(){
            this.BMI = this.weight/(this.height * this.height);
            return this.BMI;
      }
}

john.birthyear=1996;
john.calBMI();
Mark.calBMI();
console.log(john);
console.log(Mark);

*/
