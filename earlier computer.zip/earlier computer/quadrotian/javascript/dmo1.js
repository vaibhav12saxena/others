 function showdata()
    {
        var anotherwindow;
        var Employee
        var it;
        var sal=document.getElementById("salary").value;
        var salary = parseInt(sal);

        var totalsal=(salary*.12)+1000; 

        food = document.getElementById("EmployeeID").value;

        it = document.getElementById("name").value;
        anotherwindow = window.open("","","height=200","width200","top=");
        anotherwindow.document.write(food);
      
        anotherwindow.document.write(it); 
         anotherwindow.document.write("salary" +totalsal);    
  
}