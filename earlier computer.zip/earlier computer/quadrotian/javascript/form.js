
function showdata(){
 var anotherwindow;
 var sal= document.getElementById("esal").value;
 var empid= document.getElementById("empid").value;
 var name= document.getElementById("name").value;
 var esal= parseInt(sal);

 var totalsal= (esal*.12)+1000;


 anotherwindow = window.open("");
 anotherwindow.document.write("Employeeid &nbsp" +empid+"<br> Name &nbsp" +name+"<br> Salary &nbsp" +totalsal);
 anotherwindow.document.write();
 anotherwindow.document.write();
}
