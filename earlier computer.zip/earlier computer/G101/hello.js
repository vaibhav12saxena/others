/*console.log("Hello world");
// tsc -w hello.ts will autocompile
console.log("Hi");

document.write("Good boy");
*/
// let is defined locally while var is a global variable
/*function getData():string{
    return "Hello "+cname;

  
}
var cname:string="Capgemini" ;
document.getElementById("demo").innerHTML = getData();
*/
for (var i = 0; i < 5; i++) {
    console.log(i);
}
console.log(i);
